import React from 'react';
import TecnicaUno from './componentes/TecnicaUno/TecnicaUno';
import TecnicaDos from './componentes/TecnicaDos/TecnicaDos';
import TecnicaTres from './componentes/TecnicaTres/TecnicaTres';
import EstilosCondicional from './componentes/EstilosCondicional/EstilosCondicional';
import BotonCondicional from './componentes/BotonCondicional/BotonCondicional';

const App = () => {
  return (
    <div>
      <h1> Tecnicas de Renderizado </h1>
      <TecnicaUno nombre={"Firulais"}/>
      <TecnicaDos booleano/>
      <TecnicaTres booleano={false}/>
      <EstilosCondicional booleano={false} clase="nuevaClase"/>
      <BotonCondicional/>


    </div>
  )
}

export default App